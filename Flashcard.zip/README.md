`Flash Card`

## Project
It's a project depends on react native to remember the questions you study and test your self

It tested on Android

# Installation
`npm install`

# Run
`yarn start` or `npm start` to start the server